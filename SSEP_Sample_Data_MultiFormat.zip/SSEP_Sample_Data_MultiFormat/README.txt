SSEP Sample Data - Multi-format Test Package

Source:
  Uploaded ssep_economic_zones shapefile package

Coordinate systems:
  Shapefile / GeoPackage / GeoTIFF / LAS / NetCDF: EPSG:27700 (British National Grid)
  GeoJSON / GPX: EPSG:4326 (WGS 84), for interoperability

Contents:
  01_Shapefile   - SSEP economic zone polygons
  02_GeoJSON     - Same polygons as .geojson and .json
  03_GeoPackage  - economic_zones plus zone_centroids layers
  04_GeoTIFF     - 5 km raster where pixel value = SAMPLE_ID; 0 = outside zones
  05_LiDAR       - LAS 1.2 Point Format 3 synthetic elevation point cloud
  06_NetCDF      - Same zone-ID grid represented as NetCDF
  07_GPX         - First 10 zone centroids as waypoints and a sample track

Feature count: 17
LAS point count: 4250
Raster size: 131 x 243 cells
Raster cell size: 5000 m

Important:
  The LAS elevations are synthetic sample values for software/demo testing only.
  A .LAZ file is not included because LAZ requires a LASzip-compatible compressor;
  creating a file with a .laz extension without valid compression would be invalid.
  The supplied .LAS can be converted to .LAZ with ArcGIS Pro, PDAL, LAStools, or QGIS.

Use:
  Intended for import/upload/validation testing across GIS applications and data pipelines.
